# SPDX-License-Identifier: LGPL-3.0-or-later
"""NeighborGraph: backend-agnostic edge-graph neighbor-list subsystem.

The unified edge/graph neighbor-list contract and its supporting machinery:
``graph`` (the ``NeighborGraph``/``GraphLayout`` contract + derived node-validity
+ edge padding), ``csr`` (backend-agnostic CSR construction and canonicalization),
``builder`` (the carry-all ``build_neighbor_graph`` dispatcher + the
``from_dense_quartet`` legacy converter), ``segment`` (mask-aware
segment-reduction toolkit), ``from_ijs`` (ij-list -> graph conversion) and
``pairs`` (center-edge pair bookkeeping).
"""

from .builder import (
    build_neighbor_graph,
    from_dense_quartet,
    graph_from_dense_quartet,
)
from .csr import (
    attach_edge_csr,
    build_edge_csr,
    canonicalize_neighbor_graph,
)
from .from_ijs import (
    neighbor_graph_from_ijs,
)
from .graph import (
    GraphLayout,
    NeighborGraph,
    apply_pair_exclusion,
    compact_nodes,
    expand_node_values,
    frame_id_from_n_node,
    node_ownership_mask,
    node_validity_mask,
    pad_and_guard_angles,
    pad_and_guard_edges,
)
from .pairs import (
    center_edge_pairs,
)
from .segment import (
    segment_max,
    segment_mean,
    segment_softmax,
    segment_sum,
)

__all__ = [
    "GraphLayout",
    "NeighborGraph",
    "apply_pair_exclusion",
    "attach_edge_csr",
    "build_edge_csr",
    "build_neighbor_graph",
    "canonicalize_neighbor_graph",
    "center_edge_pairs",
    "compact_nodes",
    "expand_node_values",
    "frame_id_from_n_node",
    "from_dense_quartet",
    "graph_from_dense_quartet",
    "neighbor_graph_from_ijs",
    "node_ownership_mask",
    "node_validity_mask",
    "pad_and_guard_angles",
    "pad_and_guard_edges",
    "segment_max",
    "segment_mean",
    "segment_softmax",
    "segment_sum",
]

# SPDX-License-Identifier: LGPL-3.0-or-later
from typing import (
    Any,
)

import array_api_compat

from mdescriptor.descriptors.model_backed._vendor.dpa4desc.dpmodel import (
    NativeOP,
)
from mdescriptor.descriptors.model_backed._vendor.dpa4desc.dpmodel.array_api import (
    Array,
    xp_take_along_axis,
    xp_take_first_n,
)
from mdescriptor.descriptors.model_backed._vendor.dpa4desc.dpmodel.utils.safe_gradient import (
    safe_for_vector_norm,
)


def compute_smooth_weight(
    distance: Array,
    rmin: float,
    rmax: float,
) -> Array:
    r"""Compute the quintic cutoff weight.

    With :math:`u=(r-r_s)/(r_c-r_s)` clipped to :math:`[0,1]`, the weight is

    .. math::

       w(r)=1-10u^3+15u^4-6u^5.

    Thus :math:`w=1` for :math:`r\le r_s`, :math:`w=0` for
    :math:`r\ge r_c`, and the value and first two derivatives are continuous
    at both boundaries.
    """
    if rmin >= rmax:
        raise ValueError("rmin should be less than rmax.")
    xp = array_api_compat.array_namespace(distance)
    # Use where instead of clip so that make_fx tracing does not
    # decompose it into boolean-indexed ops with data-dependent sizes.
    distance = xp.where(distance < rmin, xp.full_like(distance, rmin), distance)
    distance = xp.where(distance > rmax, xp.full_like(distance, rmax), distance)
    uu = (distance - rmin) / (rmax - rmin)
    uu2 = uu * uu
    vv = uu2 * uu * (-6.0 * uu2 + 15.0 * uu - 10.0) + 1.0
    return vv


def compute_exp_sw(
    distance: Array,
    rmin: float,
    rmax: float,
) -> Array:
    r"""Compute the exponential switch used for neighbor updates.

    For a clipped distance :math:`\bar r=\min(\max(r,0),r_c)`, this computes

    .. math::

       w(r)=\exp\!\left[-\exp\!\left(\frac{20}{r_s}
       (\bar r-r_s)\right)\right].
    """
    if rmin >= rmax:
        raise ValueError("rmin should be less than rmax.")
    xp = array_api_compat.array_namespace(distance)
    distance = xp.where(distance < 0.0, xp.zeros_like(distance), distance)
    distance = xp.where(distance > rmax, xp.full_like(distance, rmax), distance)
    C = 20
    a = C / rmin
    b = rmin
    exp_sw = xp.exp(-xp.exp(a * (distance - b)))
    return exp_sw


def _make_env_mat(
    nlist: Any,
    coord: Any,
    rcut: float,
    ruct_smth: float,
    radial_only: bool = False,
    protection: float = 0.0,
    use_exp_switch: bool = False,
) -> tuple[Any, Any, Any]:
    """Make smooth environment matrix."""
    xp = array_api_compat.array_namespace(nlist)
    nf, nloc, nnei = nlist.shape
    # nf x nall x 3
    # Callers may pass either (nf, nall*3) or (nf, nall, 3); normalise
    # both to (nf, nall, 3) using shape-based inference so the concrete nf
    # value is not baked into the reshape.
    if coord.ndim == 2:
        coord = xp.reshape(coord, (-1, coord.shape[1] // 3, 3))
    mask = nlist >= 0
    nlist = nlist * xp.astype(mask, nlist.dtype)
    # nf x (nloc x nnei) x 3
    index = xp.tile(xp.reshape(nlist, (nf, -1, 1)), (1, 1, 3))
    coord_r = xp_take_along_axis(coord, index, 1)
    # nf x nloc x nnei x 3
    coord_r = xp.reshape(coord_r, (nf, nloc, nnei, 3))
    # nf x nloc x 1 x 3
    coord_l = xp.reshape(xp_take_first_n(coord, 1, nloc), (nf, nloc, 1, 3))
    # nf x nloc x nnei x 3
    diff = coord_r - coord_l
    # nf x nloc x nnei
    # the grad of JAX vector_norm is NaN at x=0
    length = safe_for_vector_norm(diff, axis=-1, keepdims=True)
    # for index 0 nloc atom
    length = length + xp.astype(~xp.expand_dims(mask, axis=-1), length.dtype)
    t0 = 1 / (length + protection)
    t1 = diff / (length + protection) ** 2
    weight = (
        compute_smooth_weight(length, ruct_smth, rcut)
        if not use_exp_switch
        else compute_exp_sw(length, ruct_smth, rcut)
    )
    weight = weight * xp.astype(xp.expand_dims(mask, axis=-1), weight.dtype)
    if radial_only:
        env_mat = t0 * weight
    else:
        env_mat = xp.concat([t0, t1], axis=-1) * weight
    return env_mat, diff * xp.astype(xp.expand_dims(mask, axis=-1), diff.dtype), weight


class EnvMat(NativeOP):
    r"""Construct radial or full local environment matrices.

    For center atom :math:`i` and neighbor :math:`j`, let
    :math:`\mathbf r_{ji}=\mathbf r_j-\mathbf r_i` and
    :math:`r_{ji}=\lVert\mathbf r_{ji}\rVert`.  Before optional
    type-dependent normalization, the full row is

    .. math::

       \mathcal R_{ij}=w(r_{ji})\left(
       \frac{1}{r_{ji}+p},
       \frac{\mathbf r_{ji}}{(r_{ji}+p)^2}\right),

    where :math:`p` is ``protection``.  In radial-only mode only the first
    component is returned.  If statistics are supplied, the final matrix is
    :math:`(\mathcal R_{ij}-\mu_{t_i j})/\sigma_{t_i j}`.
    """

    def __init__(
        self,
        rcut: float,
        rcut_smth: float,
        protection: float = 0.0,
        use_exp_switch: bool = False,
    ) -> None:
        self.rcut = rcut
        self.rcut_smth = rcut_smth
        self.protection = protection
        self.use_exp_switch = use_exp_switch

    def call(
        self,
        coord_ext: Array,
        atype_ext: Array,
        nlist: Array,
        davg: Array | None = None,
        dstd: Array | None = None,
        radial_only: bool = False,
    ) -> tuple[Array, Array, Array]:
        r"""Compute the environment matrix.

        This evaluates the :class:`EnvMat` equation for every neighbor-list
        entry, masks padded neighbors, and applies the optional normalization
        :math:`(\mathcal R-\mathrm{davg})/\mathrm{dstd}`.

        Parameters
        ----------
        nlist
            The neighbor list. shape: nf x nloc x nnei.  Entries equal to ``-1``
            mark empty neighbor slots, and a virtual center (whose atom type is
            negative) must have an entire neighbor row of ``-1``; the in-tree
            builder (``deepmd.dpmodel.utils.nlist.build_neighbor_list``) fills
            the full row of a virtual atom with ``-1`` by construction.
        coord_ext
            The extended coordinates of atoms. shape: nf x (nallx3)
        atype_ext
            The extended aotm types. shape: nf x nall
        davg
            The data avg. shape: nt x nnei x (4 or 1)
        dstd
            The inverse of data std. shape: nt x nnei x (4 or 1)
        radial_only
            Whether to only compute radial part of the environment matrix.
            If True, the output will be of shape nf x nloc x nnei x 1.
            Otherwise, the output will be of shape nf x nloc x nnei x 4.
            Default: False.

        Returns
        -------
        env_mat
            The environment matrix. shape: nf x nloc x nnei x (4 or 1)
        diff
            The relative coordinate of neighbors. shape: nf x nloc x nnei x 3
        switch
            The value of switch function. shape: nf x nloc x nnei
        """
        xp = array_api_compat.array_namespace(coord_ext, atype_ext, nlist)
        em, diff, sw = self._call(nlist, coord_ext, radial_only)
        nf, nloc, nnei = nlist.shape
        atype = xp_take_first_n(atype_ext, 1, nloc)
        center_is_real = atype >= 0
        # Virtual atoms use a negative type sentinel.  Never pass that sentinel to
        # ``take``: NumPy treats -1 as the final real type, while stricter array
        # namespaces may reject it.  Type zero is only a safe placeholder because
        # the gathered rows are neutralized below.
        safe_atype = xp.where(center_is_real, atype, xp.zeros_like(atype))
        center_mask = xp.reshape(center_is_real, (nf, nloc, 1, 1))
        # ``_make_env_mat`` already zeroes em, diff and sw wherever ``nlist < 0``,
        # so a virtual center -- whose neighbor row is empty by the neighbor-list
        # contract -- leaves this function at zero as long as normalization does
        # not shift it.  Neutralizing the offset and the scale is therefore the
        # whole fix; masking em/diff/sw again afterwards would make the
        # descriptor depend on ``atype_ext``, which the compiled pt_expt DPA2
        # lower miscompiles into wrong forces.
        if davg is not None:
            center_avg = xp.reshape(
                xp.take(davg, xp.reshape(safe_atype, (-1,)), axis=0), em.shape
            )
            center_avg = xp.where(center_mask, center_avg, xp.zeros_like(center_avg))
            em -= center_avg
        if dstd is not None:
            center_std = xp.reshape(
                xp.take(dstd, xp.reshape(safe_atype, (-1,)), axis=0), em.shape
            )
            # A neutral scale avoids hidden divide-by-zero/NaN values in the
            # masked branch, which is important for differentiable backends.
            center_std = xp.where(center_mask, center_std, xp.ones_like(center_std))
            em /= center_std
        return em, diff, sw

    def _call(
        self, nlist: Any, coord_ext: Any, radial_only: bool
    ) -> tuple[Any, Any, Any]:
        em, diff, ww = _make_env_mat(
            nlist,
            coord_ext,
            self.rcut,
            self.rcut_smth,
            radial_only=radial_only,
            protection=self.protection,
            use_exp_switch=self.use_exp_switch,
        )
        return em, diff, ww

    def serialize(
        self,
    ) -> dict:
        return {
            "rcut": self.rcut,
            "rcut_smth": self.rcut_smth,
            "protection": self.protection,
            "use_exp_switch": self.use_exp_switch,
        }

    @classmethod
    def deserialize(
        cls,
        data: dict,
    ) -> "EnvMat":
        return cls(**data)
